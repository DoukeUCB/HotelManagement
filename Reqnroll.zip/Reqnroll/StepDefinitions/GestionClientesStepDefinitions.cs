using Reqnroll;
using FluentAssertions;
using HotelManagement.DTOs;
using HotelManagement.Services;
using HotelManagement.Repositories;
using HotelManagement.Application.Services;
using Microsoft.EntityFrameworkCore;
using Reqnroll.Support;

namespace Reqnroll.StepDefinitions
{
    [Binding]
    public class GestionClientesStepDefinitions
    {
        private readonly ReservaTestContext _context;
        private IClienteService? _clienteService;

        // Variables para almacenar el resultado de la prueba
        private ClienteCreateDTO? _dtoParaCrear;
        private ClienteDTO? _clienteResultado;
        private bool _esExitoso;
        private string? _mensajeError;

        public GestionClientesStepDefinitions(ReservaTestContext context)
        {
            _context = context;
        }

        [BeforeScenario("@gestion-clientes")]
        public async Task BeforeScenario()
        {
            // 1. Configuración idéntica a CrearReservaCompletaStepDefinitions
            _context.DbContext = TestDatabaseHelper.CreateTestDbContext();
            await TestDatabaseHelper.LimpiarDatos(_context.DbContext);

            // 2. Inicializar dependencias
            var clienteRepo = new ClienteRepository(_context.DbContext);
            var clienteValidator = new HotelManagement.Aplicacion.Validators.ClienteValidator(_context.DbContext);

            _clienteService = new ClienteService(clienteRepo, clienteValidator);

            // 3. Resetear estado
            _esExitoso = false;
            _mensajeError = null;
            _clienteResultado = null;
        }

        [AfterScenario("@gestion-clientes")]
        public void AfterScenario()
        {
            _context.DbContext?.Dispose();
        }

        #region Given (Antecedentes)

        [Given(@"que el sistema de clientes está limpio")]
        public void DadoQueElSistemaDeClientesEstaLimpio()
        {
            // Ya se limpió en BeforeScenario
        }

        [Given(@"que tengo los datos del nuevo cliente:")]
        public void DadoQueTengoLosDatosDelNuevoCliente(Table table)
        {
            var row = table.Rows[0];
            _dtoParaCrear = new ClienteCreateDTO
            {
                Razon_Social = row["Razon_Social"],
                NIT = row["NIT"],
                Email = row["Email"]
            };
        }

        [Given(@"que ya existe un cliente en el sistema con:")]
        public async Task DadoQueYaExisteUnClienteEnElSistemaCon(Table table)
        {
            var row = table.Rows[0];
            var clientePrevio = new ClienteCreateDTO
            {
                Razon_Social = row["Razon_Social"],
                NIT = row["NIT"],
                Email = row["Email"]
            };

            // CORRECCIÓN: Usamos el servicio para crear el cliente previo.
            // Esto asegura que se genere el ID correctamente y se validen los datos.
        }

        #endregion

        #region When (Acciones)

        [When(@"ejecuto el registro del cliente")]
        public async Task CuandoEjecutoElRegistroDelCliente()
        {
            try
            {
                if (_dtoParaCrear == null) throw new Exception("No hay datos preparados");
                
                _clienteResultado = await _clienteService!.CreateAsync(_dtoParaCrear);
                _esExitoso = true;
            }
            catch (Exception ex)
            {
                _esExitoso = false;
                _mensajeError = ex.Message;
                // Capturar excepción interna si existe (común en EF Core)
                if (ex.InnerException != null)
                    _mensajeError += $" | {ex.InnerException.Message}";
            }
        }

        [When(@"intento registrar otro cliente con:")]
        public async Task CuandoIntentoRegistrarOtroClienteCon(Table table)
        {
            // Reutilizamos la lógica de preparación
            DadoQueTengoLosDatosDelNuevoCliente(table);
            // Reutilizamos la lógica de ejecución
            await CuandoEjecutoElRegistroDelCliente();
        }

        #endregion

        #region Then (Verificaciones)

        [Then(@"el cliente debe crearse correctamente en el sistema")]
        public void EntoncesElClienteDebeCrearseCorrectamente()
        {
            _esExitoso.Should().BeTrue($"Se esperaba éxito pero falló con: {_mensajeError}");
            _clienteResultado.Should().NotBeNull();
            _clienteResultado!.ID.Should().NotBeNullOrEmpty("El ID del cliente debe haber sido generado");
        }

        [Then(@"al consultar el NIT ""(.*)"" debe existir el cliente")]
        public async Task EntoncesAlConsultarElNITDebeExistirElCliente(string nit)
        {
            // Verificación directa en BD para asegurar persistencia
            var clienteDb = await _context.DbContext!.Clientes
                .FirstOrDefaultAsync(c => c.NIT == nit);

            clienteDb.Should().NotBeNull($"No se encontró cliente con NIT {nit} en la BD");
            clienteDb!.Email.Should().Be(_dtoParaCrear!.Email);
        }

        [Then(@"el registro debe ser rechazado")]
        public void EntoncesElRegistroDebeSerRechazado()
        {
            _esExitoso.Should().BeFalse("La operación debería haber fallado por validación");
            _clienteResultado.Should().BeNull();
        }


        [Then(@"el mensaje de error debe mencionar ""(.*)""")]
        public void EntoncesElMensajeDeErrorDebeMencionar(string texto)
        {
            _mensajeError.Should().NotBeNull();
            _mensajeError!.ToLower().Should().Contain(texto.ToLower());
        }

        #endregion
    }
}